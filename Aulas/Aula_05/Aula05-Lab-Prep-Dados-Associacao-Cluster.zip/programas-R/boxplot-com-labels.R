## Carregando os pacotes necessarios
library(car) ## caso n?oo esteja instalado instale com install.packages('car', dependencies = TRUE)

## Lendo os conjuntos de dados
#censo <- read.csv('Censo.csv', header=T)
#cluster <- read.csv('Cluster-Flores.csv', header=T)
cpu <- read.csv('../arquivos-aula05/cpu.csv', header=T)

## Boxplot do Censo
#pdf('censo.pdf')
#Boxplot(censo[,1], ylab = 'Idade', main = 'Boxplot das Idades')
#dev.off()

## Boxplot do cluster-flores
# pdf('cluster.pdf')
# par(mfrow=c(2,2))
# Boxplot(cluster[,2], ylab = 'Área (ha)')
# Boxplot(cluster[,3], ylab = 'Emprego (homem-hora-ano)')
# Boxplot(cluster[,4], ylab = 'Uso de Máquina (horas-ano)')
# Boxplot(cluster[,5], ylab = 'Renda ($)')
# par(mfrow=c(1,1))
# dev.off()

## Boxplot do cpu
pdf('cpu.pdf')
par(mfrow=c(2,3))
Boxplot(cpu[,1], ylab = 'MYCT')
Boxplot(cpu[,2], ylab = 'MMIN')
Boxplot(cpu[,3], ylab = 'MMAX')
Boxplot(cpu[,4], ylab = 'CACH')
Boxplot(cpu[,5], ylab = 'CHMIN')
Boxplot(cpu[,6], ylab = 'CHMAX')
x=Boxplot(cpu[,6], ylab = 'CHMAX')
par(mfrow=c(1,1))
dev.off()
